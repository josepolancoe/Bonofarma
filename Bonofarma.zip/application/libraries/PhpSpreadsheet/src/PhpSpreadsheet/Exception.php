<?php

namespace PhpOffice\PhpSpreadsheet;

class Exception extends \Exception
{
}
